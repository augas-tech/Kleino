import Navbar from "../components/shared/Navbar.jsx";

// Placeholder: aquí va el formulario de registro conectado a POST /registration.
export default function Register() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="mx-auto flex max-w-md flex-col items-center px-6 py-24 text-center">
        <h1 className="text-2xl font-bold text-navy">Crear cuenta</h1>
        <p className="mt-2 text-slate-500">
          Formulario de registro — próximamente.
        </p>
      </main>
    </div>
  );
}

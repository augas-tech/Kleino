import Navbar from "../components/shared/Navbar.jsx";

// Placeholder: aquí va el formulario de login conectado a POST /session.
// Lo armamos en el siguiente paso, una vez definido el diseño de esta pantalla.
export default function Login() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="mx-auto flex max-w-md flex-col items-center px-6 py-24 text-center">
        <h1 className="text-2xl font-bold text-navy">Ingresar</h1>
        <p className="mt-2 text-slate-500">
          Formulario de inicio de sesión — próximamente.
        </p>
      </main>
    </div>
  );
}

// Placeholder: acá van las pantallas de los 3 CRUD (Sedes, Espacios, Reservas)
// una vez que el usuario inició sesión. Ruta protegida a futuro con
// GET /session para confirmar que hay una sesión activa.
export default function Dashboard() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50">
      <p className="text-slate-500">Panel de reservas — próximamente.</p>
    </main>
  );
}
